select 
   event,
   sum(total_waits) as total_waits,
   sum(time_waited) as time_waited,
   round(avg(average_wait),2) as avg_wait
from 
   gv$system_event
where 
   event in ('PX Deq Credit: need buffer',
             'PX Deq Credit: send blkd')
group by 
   event
order by 
   event;