select
   qcsid,
   sid,
   inst_id,
   server_group,
   case server_set
      when 1 then 'Producer'
      when 2 then 'Consumer'
      when null then 'QC'
   end as slave_type,
   server#
from
   gv$px_session
order by
   qcsid,
   server_group desc,
   inst_id,
   server_set,
   server#;