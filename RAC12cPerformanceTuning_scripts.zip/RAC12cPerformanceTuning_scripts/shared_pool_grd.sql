select   round(sum(bytes)/1024/1024,2) as total_mbfrom   v$sgastat
where
   pool='shared pool';

select
   round(sum(bytes)/1024/1024,2) as grd_mb
from
   v$sgastat
where
   name like 'gcs%'
   or
   name like 'ges%';

select
   pool,
   name,
   bytes
from
   v$sgastat
where
   name like 'gcs%'
   or
   name like 'ges%'
order by
   name;







