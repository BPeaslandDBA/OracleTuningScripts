select
   inst_id,
   sid,
   type,
   id1,
   id2,
   case
   when lmode > 0 then 'Blocker'
   else 'Waiter'
   end as action
from
   gv$lock
where
   (id1,id2) in (select
                    id1,
                    id2
                 from
                    gv$lock
                 where
                    type='TX'
                    and
                    request<>0)
order by
   id1,
   id2;