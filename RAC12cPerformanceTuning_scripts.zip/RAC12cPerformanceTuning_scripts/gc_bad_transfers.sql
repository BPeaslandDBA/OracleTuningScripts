select
   days_up,
   blocks_lost,
   blocks_corrupt
from (select 
         sum(value) as blocks_lost
      from 
         gv$sysstat
      where 
         name='gc blocks lost'),
     (select 
         sum(value) as blocks_corrupt
      from 
         gv$sysstat
      where 
         name='gc blocks corrupt'),         
     (select 
         round(sysdate-min(startup_time),2) as days_up
      from
         gv$instance);