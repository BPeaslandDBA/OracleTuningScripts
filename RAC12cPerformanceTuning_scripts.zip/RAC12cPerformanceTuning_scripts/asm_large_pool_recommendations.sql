set serveroutput on
declare
   db_file_size   number;
   log_file_size  number;
   temp_file_size number;
   tot_file_size  number; 
   recommend_size number;
begin
   select 
      sum(bytes) into db_file_size
   from 
      v$datafile;

   select 
      sum(bytes) into log_file_size
   from 
      v$log;

   select 
      sum(bytes) into temp_file_size
   from 
      v$tempfile;

   tot_file_size := (db_file_size+log_file_size+temp_file_size)/1024/1024/1024;
   dbms_output.put_line('Total DB Size (GB): '||round(tot_file_size,2)||chr(10));

   -- external redundancy
   recommend_size := round(2 + floor(tot_file_size/100),2);
   dbms_output.put_line('For External Redundancy increase Large Pool by '||recommend_size||' MB');

   -- normal redundancy
   recommend_size := round(4 + floor(tot_file_size/50),2);
   dbms_output.put_line('For Normal Redundancy increase Large Pool by '||recommend_size||' MB');

   -- high redundancy
   recommend_size := round(6 + floor(tot_file_size/33),2);
   dbms_output.put_line('For High Redundancy increase Large Pool by '||recommend_size||' MB');

end;
/