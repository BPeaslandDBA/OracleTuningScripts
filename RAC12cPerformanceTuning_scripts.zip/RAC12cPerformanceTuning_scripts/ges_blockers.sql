select
   inst_id,
   pid,
   resource_name1 as resource_name,
   blocker,
   blocked,
   owner_node
from
   gv$ges_blocking_enqueue
order by
   resource_name;