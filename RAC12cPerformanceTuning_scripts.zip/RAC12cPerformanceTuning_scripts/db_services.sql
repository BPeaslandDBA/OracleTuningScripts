select
   inst_id,
   name
from
   gv$services
where
   name not in ('SYS$BACKGROUND',
                'SYS$USERS')
   and
   name not like '%XDB'
   and
   upper(name) not in (select
                          name
                       from
                          v$database);


