column event format a30

select
   *
from 
(select
   event,
   total_waits,
   time_waited
from
   v$session_event
where
   sid=SYS_CONTEXT('USERENV','SID')
order by
   time_waited desc)
where
   rownum <=5;
