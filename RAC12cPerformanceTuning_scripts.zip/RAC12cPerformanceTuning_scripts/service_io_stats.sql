select
   service_name,
   stat_name,
   sum(value) as total_val
from
   gv$service_stats
where
   stat_name like 'physical%'
   and
   service_name not like 'SYS%'
group by
   service_name,
   stat_name
order by
   service_name,
   stat_name;
