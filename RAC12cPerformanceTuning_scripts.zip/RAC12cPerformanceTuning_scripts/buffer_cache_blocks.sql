-- Run for each instance id to obtain
-- number of blocks in each instance’s cache
 
select 
   count(*) as num_blocks 
from (
   select distinct 
      file#,
      block# 
   from 
      gv$bh
   where 
      inst_id=1);

-- Run once to determine how many blocks 
-- are the same in all caches. 

select 
   count(*) as num_shared_blks
from (
   select distinct 
      file#,
      block# 
   from 
      gv$bh 
   where 
      inst_id=1
   intersect 
   select distinct 
      file#,
      block# 
   from 
      gv$bh 
   where 
      inst_id=2
   intersect 
   select distinct 
      file#,
      block# 
   from 
      gv$bh 
   where 
      inst_id=3);
