select 
   sum(value) as total_downgraded
from 
   gv$sysstat
where
   name like 'Parallel operations downgraded%';
