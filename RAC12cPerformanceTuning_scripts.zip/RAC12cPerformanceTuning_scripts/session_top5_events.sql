set verify off
accept v_instid prompt 'Enter Instance Id: '
accept v_sid    prompt 'Enter SID: '
select
   *
from (
   select 
      event,
      to_char(time_waited,'999,999,999') as time_waited,
      to_char(round(ratio_to_report(time_waited) over ()*100,2),'990.00') as "WAIT%"
   from 
      gv$session_event
   where 
      inst_id = &v_instid
      and
      sid = &v_sid
      and 
      event not in (select 
                       name 
                    from 
                       v$event_name
                    where 
                       wait_class='Idle')
   order by 
      time_waited desc)
where
   rownum <= 5;