select 
   instance_name,
   sum(value) as blocks_received
from
   gv$sysstat ss
join
   gv$instance i
on 
  ss.inst_id=i.inst_id   
where
   name in ('gc cr blocks received',
            'gc current blocks received')
group by
   instance_name
order by 
   instance_name;
            