set serveroutput on
declare
   cpu_cnt   number;
   t_per_cpu number;
   inst_cnt  number;
begin
   select
      value into t_per_cpu
   from 
      v$parameter
   where 
      name='parallel_threads_per_cpu';

   select
      value into cpu_cnt
   from
      v$parameter
   where
      name='cpu_count';

   select
      count(*) into inst_cnt
   from
      gv$instance;

   dbms_output.put_line('Default DOP: ' || cpu_cnt * t_per_cpu * inst_cnt);

end;
/