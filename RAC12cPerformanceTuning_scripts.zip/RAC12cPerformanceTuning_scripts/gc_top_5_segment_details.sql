select
   top5.owner,
   top5.object_name,
   stats.statistic_name,
   sum(stats.value) as total_value
from (
      select 
         owner,
         object_name
      from (
         select 
            owner,
            object_name,
            sum(value)
         from 
            gv$segment_statistics
         where 
            statistic_name like 'gc%'
         group by 
            owner,
            object_name
         order by 
            sum(value) desc)
      where 
         rownum <= 5) top5
join
   gv$segment_statistics stats
on top5.owner = stats.owner
   and
   top5.object_name = stats.object_name
where 
   stats.statistic_name like 'gc%'
group by
   top5.owner,
   top5.object_name,
   stats.statistic_name
order by
   top5.owner,
   top5.object_name,
   stats.statistic_name;