﻿---------------------------------------------

Oracle RAC Performance Tuning Script Library

---------------------------------------------



This file contains the scripts shown in the book

Oracle RAC Performance Tuning by Brian Peasland

published on Rampant TechPress 2015. 



This zip file is provided on GitHub for those 
that may be 
experiencing trouble downloading 
from the publisher’s web site. 


If you have not purchased a copy of this book, please do so now!