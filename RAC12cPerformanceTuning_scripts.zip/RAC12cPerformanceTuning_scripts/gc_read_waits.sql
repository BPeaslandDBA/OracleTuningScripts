select 
   a.inst_id,
   a.value as read_waits,
   b.value as read_wait_time,
   b.value/a.value as “avg_time_per_wait(ms)”
from
   (select 
      inst_id,
      name,
      value
   from 
      gv$sysstat
   where 
      name ='gc read waits') a,
   (select 
      inst_id,
      name,
      value
   from 
      gv$sysstat
   where 
      name ='gc read wait time') b
where 
   a.inst_id=b.inst_id
order by
   a.inst_id;