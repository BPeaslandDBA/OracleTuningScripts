select 
   round(min(grd_bytes)/1024/1024,2) as min_grd_mbytes, 
   round(avg(grd_bytes)/1024/1024,2) as avg_grd_mbytes,
   round(max(grd_bytes)/1024/1024,2) as max_grd_mbytes
from (
   select 
      snap_id,
      sum(bytes) as grd_bytes
   from 
      dba_hist_sgastat
   where 
      pool='shared pool'
      and 
         (name like 'gcs%' 
          or 
          name like 'ges%')
   group by 
      snap_id);


